// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getFirestore } from "firebase/firestore";
// import { getAuth } from "firebase/auth";
// import { getStorage } from "firebase/storage";

// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyDWGdN09ZilPfGaVCJ-v_5gZ1i2AWrwmxA",
//   authDomain: "jis-blog.firebaseapp.com",
//   projectId: "jis-blog",
//   storageBucket: "jis-blog.appspot.com",
//   messagingSenderId: "884759154390",
//   appId: "1:884759154390:web:a332017a9661e22adc4377",
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// export const db = getFirestore(app);
// export const auth = getAuth();
// export const storage = getStorage(app);
